﻿namespace CarManufacturer
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Car car = new Car
            {
                Make = "Toyota",
                Model = "Corolla",
                Year = 2020
            };
        }
    }
}