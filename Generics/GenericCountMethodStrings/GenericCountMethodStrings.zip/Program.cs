﻿class Box<T> : IComparable<Box<T>>
{
    public T Value { get; set; }

    public Box(T value)
    {
        Value = value;
    }

    public int CompareTo(Box<T> other)
    {
        return Value.ToString().CompareTo(other.Value.ToString());
    }
}
class Program
{
    static void Main(string[] args)
    {
        int n = int.Parse(Console.ReadLine());

        List<Box<string>> boxes = new();
        for (int i = 0; i < n; i++)
        {
            string input = Console.ReadLine();

            boxes.Add(new Box<string>(input));
        }

        string elementToCompare = Console.ReadLine();
        
        boxes.Add(new Box<string>(elementToCompare));
        boxes.Sort();

        int count = 0;
        for(int i = boxes.Count - 1; i >= 0; i--)
        {
            if (boxes[i].Value.ToString() == elementToCompare)
            {
                break;
            }
            count++;
        }
        Console.WriteLine(count);
    }
}