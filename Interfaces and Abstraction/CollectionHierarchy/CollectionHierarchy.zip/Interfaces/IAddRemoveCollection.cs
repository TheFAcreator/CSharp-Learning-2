﻿namespace CollectionHierarchy.Interfaces
{
    public interface IAddRemoveCollection : IAddCollection
    {
        public string Remove();
    }
}
