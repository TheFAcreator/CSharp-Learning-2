﻿namespace FoodShortage
{
    public interface IIdentifiable
    {
        string Name { get; }
        int Age { get; }
        int Food { get; }
    }
}
