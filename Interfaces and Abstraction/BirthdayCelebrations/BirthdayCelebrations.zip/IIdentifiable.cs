﻿namespace BirthdayCelebrations
{
    public interface IIdentifiable
    {
        string Name { get; }
        string Birthdate { get; }
    }
}
