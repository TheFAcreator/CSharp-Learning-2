﻿namespace WildFarm.Foods
{
    public class Meat : Food
    {
        public Meat(int quantity)
        {
            Quantity = quantity;
        }
    }
}
