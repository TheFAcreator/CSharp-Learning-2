﻿namespace WildFarm.Foods
{
    public class Fruit : Food
    {
        public Fruit(int quantity)
        {
            Quantity = quantity;
        }
    }
}
