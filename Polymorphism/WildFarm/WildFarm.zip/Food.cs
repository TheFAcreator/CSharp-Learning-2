﻿namespace WildFarm
{
    public abstract class Food
    {
        public int Quantity { get; set; }
    }
}
