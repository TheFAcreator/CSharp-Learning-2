﻿namespace Vehicles
{
    public class Car : Vehicle
    {
        public Car(double fuelQuantity, double fuelConsumption)
            : base(fuelQuantity, fuelConsumption + 0.9)
        {
        }

        public override void Refuel(double liters)
        {
            FuelQuantity += liters;
        }
    }
}
